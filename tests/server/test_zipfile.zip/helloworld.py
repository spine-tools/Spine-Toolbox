with open("input2.txt") as input_file:
    print(input_file.read())